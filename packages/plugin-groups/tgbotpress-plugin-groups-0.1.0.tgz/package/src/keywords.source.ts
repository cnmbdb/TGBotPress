export const recommendedGroupAdKeywords = [
  '博彩','赌场','下注','包赢','刷单','跑分','洗钱','空投群','资金盘','高薪兼职','日赚','稳赚','保本收益','代开发票','出售账号','收购账号','免费空投','担保交易','无押贷款','裸聊','色粉','盘口','娱乐城','代理招商','渠道合作','低价出售','限时优惠','免费领取','加我咨询','私聊咨询','联系我','承兑','代付','换汇','引流','推广','招聘','广告合作','广告位','商务合作','项目推广','资源对接','招代理','加群','进群','群发','拉人','代收','代充','收u','出u','币商','群演招募','兼职日结','刷单返利','项目招商','项目返佣盘','高收益理财','USDT承兑','账号买卖','引流获客','资源对接群','贷款下款','棋牌博彩','盘口代理','虚拟币搬砖','跑分车队','卡商料商','话费慢充','礼品卡回收','回收礼品卡','担保换汇','空投拉新','直播色粉','裸聊敲诈','证件办理','免费领币','加群领福利','私聊报价','联系飞机客服','招代理返佣','代收代付','兜比脸干净',
] as const

export function splitModerationKeywords(value: string | null | undefined): string[] {
  return String(value ?? '').split(/[,，\r\n]+/u).map(keyword => keyword.trim()).filter(Boolean)
}

function uniqueKeywords(values: string[]): string[] {
  const seen = new Set<string>()
  return values.filter(keyword => {
    const normalized = keyword.toLocaleLowerCase('und')
    if (seen.has(normalized)) return false
    seen.add(normalized)
    return true
  })
}

/** Remove previously materialized system keywords from legacy rows, leaving only group-owned terms. */
export function customGroupAdKeywords(groupKeywords: string | null | undefined, sharedKeywords: string | null | undefined): string[] {
  const managed = new Set([
    ...recommendedGroupAdKeywords,
    ...splitModerationKeywords(sharedKeywords),
  ].map(keyword => keyword.toLocaleLowerCase('und')))
  return uniqueKeywords(splitModerationKeywords(groupKeywords).filter(keyword => !managed.has(keyword.toLocaleLowerCase('und'))))
}

export function effectiveGroupAdKeywords(
  groupKeywords: string | null | undefined,
  sharedKeywords: string | null | undefined,
  autoUpload: boolean | null | undefined,
  autoSync: boolean | null | undefined,
): string[] {
  const includeRecommended = autoUpload == null || autoUpload
  const includeShared = autoSync == null || autoSync
  return uniqueKeywords([
    ...customGroupAdKeywords(groupKeywords, sharedKeywords),
    ...(includeRecommended ? [...recommendedGroupAdKeywords] : []),
    ...(includeShared ? splitModerationKeywords(sharedKeywords) : []),
  ])
}
